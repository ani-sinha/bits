# Stub module to support modules that import tempfile but don't always call it
