#!/bin/sh

grub_modinfo_target_cpu=i386
grub_modinfo_platform=pc
